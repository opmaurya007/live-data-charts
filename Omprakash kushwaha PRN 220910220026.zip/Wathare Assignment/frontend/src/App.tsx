import 'bootstrap/dist/css/bootstrap.css';
import StudentForm from './components/studentForm/StudentForm';
import View from './components/view/View';
import Header from './components/header/Header';
function App() {
  return (
    <>
      <Header />
      <View />
      <StudentForm />
    </>
  )
}

export default App
