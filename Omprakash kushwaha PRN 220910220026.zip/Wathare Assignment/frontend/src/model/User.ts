export interface User  {
    name : string;
    gender:string;
    Physics:number;
    Maths:number;
    English:number;
 
}