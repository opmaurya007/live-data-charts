import React, { useState, ChangeEvent, FormEvent } from 'react';
import './StudentForm.css';
import axios from 'axios';

interface FormData {
    name: string;
    gender: string;
    Physics: string;
    Maths: string;
    English: string;
}

const StudentForm: React.FC = () => {
    const [formData, setFormData] = useState<FormData>({
        name: '',
        gender: '',
        Physics: '',
        Maths: '',
        English: '',
    });

    const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();

        axios.post('http://localhost:2020/student', formData)
            .then((response) => {
                console.log(response.data);
            })
            .catch((error) => {
                console.error('Error posting data:', error);
            });
    };

    return (
        <div className="form-container">
            <h1 className="form-title">Student Data Entry Form</h1>
            <form onSubmit={handleSubmit}>
                <label className="form-label" htmlFor="Name">Name: </label>
                <input className="form-input" required type="text" name="name" value={formData.name} onChange={handleChange} required /><br />

                <label className="form-label" htmlFor="gender">Gender:</label>
                <select className="form-input" required name="gender" value={formData.gender} onChange={handleChange} required>
                    <option value="">Select Gender</option>
                    <option value="male">Male</option>
                    <option value="female">Female</option>
                    <option value="other">Other</option>
                </select><br />

                <label className="form-label" htmlFor="Physics">Physics Grade:</label>
                <input className="form-input" required type="text" name="Physics" value={formData.Physics} onChange={handleChange} required /><br />

                <label className="form-label" htmlFor="Maths">Maths Grade:</label>
                <input className="form-input" required type="text" name="Maths" value={formData.Maths} onChange={handleChange} required /><br />

                <label className="form-label" htmlFor="English">English Grade:</label>
                <input className="form-input" required type="text" name="English" value={formData.English} onChange={handleChange} required /><br />

                <button className="form-button" type="submit">Submit</button>
            </form>
        </div>
    );
};

export default StudentForm;
