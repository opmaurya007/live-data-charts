import { useState, useEffect } from "react";
import axios from 'axios';

import { PieChart, Pie, Cell, Tooltip, Legend } from "recharts";
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import './view.css';
import { User } from "../../model/User";

const View = () => {
  const [data, setData] = useState<User[]>([]);
  const [selectedSubject, setSelectedSubject] = useState<keyof User>("Physics");
  const [selectedStudent, setSelectedStudent] = useState<string>('');

  const colors = ["#FF5733", "#33FF57", "#5733FF", "#FF33E1", "#33E1FF", "#E1FF33"];

  useEffect(() => {
    axios
      .get("http://localhost:2020/student")
      .then((response) => {
        setData(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const selectedData = data
    .filter((student) => selectedStudent === '' || student.name === selectedStudent)
    .map((student) => ({
      name: new Date(student.timestamp).toLocaleDateString(),
      totalMarks: Number(student.Physics) + Number(student.Maths) + Number(student.English),
    }));

  const selectedDataStudent = data
    .filter((student) => selectedStudent === '' || student.name === selectedStudent)
    .reduce((acc, student) => {
      acc.push({ name: "Physics", value: Number(student.Physics) });
      acc.push({ name: "Maths", value: Number(student.Maths) });
      acc.push({ name: "English", value: Number(student.English) });
      return acc;
    }, []);

  ;

  const handleStudentChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedStudent(event.target.value);
  };

  const handleSubjectChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedSubject(event.target.value as keyof User);
  };

  return (
    <div>
      {data.length === 0 ? (
        <div>Loading...</div>
      ) : (
        <div>
          <div>
            <label htmlFor="student-select">Select a student:</label>
            <select id="student-select" value={selectedStudent} onChange={handleStudentChange}>
              <option value="">All Students</option>
              {data.map((student) => (
                <option key={student.name} value={student.name}>
                  {student.name}
                </option>
              ))}
            </select>
          </div>

          <div className="data">
            <div>
              <LineChart width={700} height={400} data={selectedData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis dataKey="totalMarks" />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="totalMarks" stroke="#8884d8" />
              </LineChart>
            </div>
            <div>
              {selectedDataStudent.length > 0 ? (
                <PieChart width={700} height={500}>
                  <Pie
                    data={selectedDataStudent}
                    dataKey="value"
                    nameKey="name"
                    outerRadius={200}
                    fill="#8884d8"
                  >
                    {selectedDataStudent.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend />
                </PieChart>
              ) : (
                <div>No data available for the selected student.</div>
              )}
            </div>

          </div>
        </div>
      )}
    </div>
  );
};

export default View;
