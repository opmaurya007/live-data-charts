import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { User } from "../../model/User";
const Range = () => {

   const initialData: User[] = [
      {
         name: 'arun',
         gender: 'Male',
         Physics: 88,
         Maths: 87,
         English: 78
      },
      {
         name: 'rajesh',
         gender: 'Male',
         Physics: 96,
         Maths: 100,
         English: 95
      },
      {
         name: 'moorthy',
         gender: 'Male',
         Physics: 89,
         Maths: 90,
         English: 70
      },
      {
         name: 'raja',
         gender: 'Male',
         Physics: 30,
         Maths: 25,
         English: 40
      },
      {
         name: 'usha',
         gender: 'Female',
         Physics: 67,
         Maths: 45,
         English: 78
      },
      {
         name: 'priya',
         gender: 'Female',
         Physics: 56,
         Maths: 46,
         English: 78
      },
      {
         name: 'Sundar',
         gender: 'Male',
         Physics: 12,
         Maths: 67,
         English: 67
      },
      {
         name: 'Kavitha',
         gender: 'Female',
         Physics: 78,
         Maths: 71,
         English: 67
      },
      {
         name: 'Dinesh',
         gender: 'Male',
         Physics: 56,
         Maths: 45,
         English: 67
      },
      {
         name: 'Hema',
         gender: 'Female',
         Physics: 71,
         Maths: 90,
         English: 23
      },
      {
         name: 'Gowri',
         gender: 'Female',
         Physics: 100,
         Maths: 100,
         English: 100
      },
      {
         name: 'Ram',
         gender: 'Male',
         Physics: 78,
         Maths: 55,
         English: 47
      },
      {
         name: 'Murugan',
         gender: 'Male',
         Physics: 34,
         Maths: 89,
         English: 78
      },
      {
         name: 'Jenifer',
         gender: 'Female',
         Physics: 67,
         Maths: 88,
         English: 90
      }
   ]



   const subjects: (keyof User)[] = ["Physics", "Maths", "English"];

   const [selectedSubject, setSelectedSubject] = useState<keyof User>(subjects[0]);
   const selectedData = initialData.map((student) => ({
      name: student.name,
      marks: student[selectedSubject],
   }));

   const handleSubjectChange = (event) => {
      setSelectedSubject(event.target.value);
   };

   return (
      <div>
         <div>
            <label htmlFor="subject-select">Select a subject:</label>
            <select id="subject-select" value={selectedSubject} onChange={handleSubjectChange}>
               {subjects.map((subject) => (
                  <option key={subject} value={subject}>
                     {subject}
                  </option>
               ))}
            </select>
         </div>
         <BarChart width={700} height={400} data={selectedData}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="marks" fill="#8884d8" />
         </BarChart>
      </div>
   );
};


export default Range