const Student = require("../db/model");
const express = require("express");
const router = express.Router();

router.get("/", (req, res) => {
  Student.find()
    .then(function (students) {
      res.json(students);
    })
    .catch((err) => {
      console.log(err);
    });
});

router.get("/:id", (req, res) => {
  const id = req.params.id;
  Student.findById(id)
    .then((student) => {
      if (!student) {
        return res.json({ Error: "Student not found" });
      }
      res.json(student);
    })
    .catch((err) => {
      console.log(err);
      res.json({ Error: "Internal Server Error" });
    });
});

router.post("/", (req, res) => {
  const { name, gender, Physics, Maths, English } = req.body;

  if (!req.body) {
    return res.json({ Error: "Incomplete Data" });
  }
  const newStudent = new Student({
    name,
    gender,
    Physics,
    Maths,
    English,
  });

  newStudent
    .save()
    .then((savedStudent) => {
      res.json(savedStudent);
    })
    .catch((err) => {
      console.log(err);
      res.json({ Error: "Fail to save data" });
    });
});

router.put("/:id", () => {});

router.delete("/:id", (req, res) => {
  const id = req.params.id;
  Student.findByIdAndDelete(id)
    .then((deletedStudent) => {
      if (!deletedStudent) {
        return res.json({ error: "Student not found" });
      }

      res.json({ message: "Student deleted successfully" });
    })
    .catch((err) => {
      console.log(err);
      res.json({ error: "Internal Server Error" });
    });
});

module.exports = router;
