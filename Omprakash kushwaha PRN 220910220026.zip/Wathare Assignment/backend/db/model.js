const mongoose = require("mongoose");
mongoose.connect(
  "mongodb+srv://root123:root123@swapnil.jiey6zu.mongodb.net/?retryWrites=true&w=majority"
);

const StudentSchema = new mongoose.Schema({
  name: String,
  gender: String,
  Physics: Number,
  Maths: Number,
  English: Number,
});

const StudentModel = mongoose.model("student", StudentSchema);

module.exports = StudentModel;
