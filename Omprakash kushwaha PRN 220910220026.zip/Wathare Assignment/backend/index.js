const express = require("express");
const app = express();
const userRouter = require("./routes/User");
const bodyParser = require("body-parser");
const cors = require("cors");
app.use(cors());
app.use(bodyParser.json());
app.use("/student", userRouter);

app.listen(2020, () => {
  console.log("server started at port 2020");
});
