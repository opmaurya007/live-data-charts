const LiveData = require('../server');

exports.getAllData = async (req, res) => {
  try {
    const data = await LiveData.find().sort({ timestamp: -1 }).limit(100);
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'Error fetching data from the database' });
  }
};
