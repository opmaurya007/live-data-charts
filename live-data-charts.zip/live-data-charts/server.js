const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');
const Data = require('./dataModel'); 
const app = express();
const PORT = process.env.PORT || 5000;
app.use(bodyParser.json());
app.use(cors());

// Connect to MongoDB
// mongoose.connect("mongodb://localhost:27017/live_data", {
//   useNewUrlParser: true,
//   useUnifiedTopology: true,
// }, (err) => {
//   if (err) {
//     console.error('Error connecting to MongoDB:', err);
//   } else {
//     console.log('Connected to MongoDB!');
//   }
// });
mongoose
  .connect('mongodb://localhost:27017/live_data', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() => {
    console.log('Connected to MongoDB!');
  })
  .catch((error) => {
    console.error('Error connecting to MongoDB:', error);
  });

 
const connection = mongoose.connection;
connection.once('open', () => {
  console.log('MongoDB database connection established successfully');
});

app.get('/api/data', async (req, res) => {
    try {
      // Fetch data from MongoDB using Mongoose
      const data = await Data.find();
  
      // Log the fetched data to the console
      console.log('Test data:', data);
  
      res.json(data);
    } catch (error) {
      console.error('Error fetching data from the server:', error);
      res.status(500).json({ error: 'Error fetching data from the server' });
    }
  }); 
  
 
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});


const liveDataSchema = new mongoose.Schema({
  timestamp: { type: Date, default: Date.now },
  value: Number,
});

const LiveData = mongoose.model('LiveData', liveDataSchema);

module.exports = LiveData;

