import React from 'react';
import './App.css';
import LiveDataChart from './components/LiveDataChart';

const App: React.FC = () => {
  return (
    <div className="App">
      <LiveDataChart />
    </div>
  );
};

export default App;
